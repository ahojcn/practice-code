/*
 通讯录v2
 */

#include "contact.h"

int main(int argc, const char * argv[])
{
    LoginCtrl();
    
    return 0;
}
